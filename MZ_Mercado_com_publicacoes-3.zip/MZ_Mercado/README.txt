MZ MERCADO — versão demonstrativa
1. Extraia o ZIP.
2. Abra o ficheiro index.html no Chrome.
3. O site funciona sem internet para a demonstração.
4. Para colocar online, publique o index.html num serviço de hospedagem estática.

Funções incluídas:
- Pesquisa
- Categorias
- Ofertas e anúncios em destaque
- Favoritos
- Contactar/Comprar
- Formulário de publicação de anúncios
- Layout adaptado ao telemóvel
